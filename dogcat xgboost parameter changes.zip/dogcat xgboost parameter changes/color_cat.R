library(psych)
library(xgboost)


cat_color_training <- read.csv("cat_color_training_rdat.csv", header = TRUE)
#View(cat_color_training)
#str(cat_color_training)

cat_color_training$Domestic.Indc <- as.factor(cat_color_training$Domestic.Indc)

cat_indicator <- as.logical(cat_color_training$Color.Indc)
cat_color_training <- cat_color_training[cat_indicator,]

cat_sex <- dummy.code(cat_color_training$Sex)
#View(cat_sex)

cat_intake <- dummy.code(cat_color_training$Intake.Type)
#View(cat_intake)

cat_shelter <- dummy.code(cat_color_training$Shelter)
#View(cat_shelter)

cat_micro <- dummy.code(cat_color_training$Micro.Date..Factor.)
#View(cat_micro)

cat_color <- dummy.code(cat_color_training$Primary.Color)
cat_color <- cat_color[,-c(7,11)]
#View(cat_color)

cat_domestic <- dummy.code(cat_color_training$Domestic.Indc)
#View(cat_domestic)

cat_DOW <- dummy.code(cat_color_training$DOW)
#View(cat_DOW)

cat_YEAR <- dummy.code(cat_color_training$YEAR)
#view(cat_YEAR)


cat_color_training$OutCatg.Mod <- as.numeric(unclass(factor(cat_color_training$OutCatg.Mod))-1)

cat_color_training_final <- data.frame(cat_sex,cat_intake,cat_shelter,cat_micro,cat_color,cat_domestic,
                                       cat_DOW, cat_YEAR,
                                       cat_color_training$Age,cat_color_training$Length.of.Stay,
                                       cat_color_training$Month, cat_color_training$Population,
                                       cat_color_training$OutCatg.Mod)

bstDense5 <- xgboost(data = as.matrix(cat_color_training_final[,-58]), label = cat_color_training_final[,58], 
                    missing=NaN, max.depth = 9, eta = 0.01, nround = 3000, num_class=3,
                    objective = "multi:softprob")

#xgb.plot.importance(xgb.importance(colnames(cat_color_training_final[,-58]), model = bstDense5))


#_________


cat_color_test <- read.csv("cat_color_test_rdat.csv", header = TRUE)
#View(cat_color_test)
#str(cat_color_test)

cat_color_test_copy <- read.csv("cat_color_test_rdat.csv", header = TRUE)

cat_color_test$Domestic.Indc <- as.factor(cat_color_test$Domestic.Indc)

cat_indicator_test <- as.logical(cat_color_test$Color.Indc)
cat_color_test <- cat_color_test[cat_indicator_test,]

cat_color_test_copy <- cat_color_test_copy[cat_indicator_test,]

cat_sex_test <- dummy.code(cat_color_test$Sex)
#View(cat_sex_test)

cat_intake_test <- dummy.code(cat_color_test$Intake.Type)
#View(cat_intake_test)

cat_shelter_test <- dummy.code(cat_color_test$Shelter)
#View(cat_shelter_test)

cat_micro_test <- dummy.code(cat_color_test$Micro.Date..Factor.)
#View(cat_micro_test)

cat_prim_color_test <- dummy.code(cat_color_test$Primary.Color)
cat_prim_color_test <- cat_prim_color_test[,-c(7,11)]
#View(cat_prim_color_test)

cat_domestic_test <- dummy.code(cat_color_test$Domestic.Indc)
#View(cat_domestic)

cat_DOW_test <- dummy.code(cat_color_test$DOW)
#View(cat_DOW_test)

cat_YEAR_test <- dummy.code(cat_color_test$YEAR)
#view(cat_YEAR_test)

cat_color_test_final <- data.frame(cat_sex_test,cat_intake_test,cat_shelter_test,cat_micro_test,
                                   cat_prim_color_test,cat_domestic_test,
                                       cat_DOW_test, cat_YEAR_test,
                                       cat_color_test$Age,cat_color_test$Length.of.Stay,
                                       cat_color_test$Month, cat_color_test$Population)

pred5 <- predict(bstDense5, as.matrix(cat_color_test_final), missing=NaN)
mypred5 <- data.frame(cat_color_test_copy$ARN,matrix(pred5, ncol=3, byrow=TRUE))
names(mypred5) <- c("ARN","ADOPTION","EUTHANASIA","OTHER")
write.csv(mypred5, file="mypred5cp4.csv", row.names=FALSE)

