library(psych)
library(xgboost)

breed_no_color_train <- read.csv("breed_no_color_training_rdat.csv", header = TRUE)
#View(breed_no_color_train)
#str(breed_no_color_train)
indicator_vec2 <- as.logical(breed_no_color_train$Indicator)
breed_no_color_train <- breed_no_color_train[indicator_vec2,]

sex_dummy2 <- dummy.code(breed_no_color_train$Sex)
#View(sex_dummy2)

shelter_dummy2 <- dummy.code(breed_no_color_train$Shelter)
#View(shelter_dummy2)

#color_dummy2 <- dummy.code(breed_no_color_train$Primary.Color)
#color_dummy2 <- color_dummy2[,-c(4,9)]
#View(color_dummy2)

micro_factor2 <- dummy.code(breed_no_color_train$Micro.Date..Factor.)
#View(micro_factor2)

license_factor2 <- dummy.code(breed_no_color_train$License.Date..Factor.)
#View(license_factor2)

AKC_factor2 <- dummy.code(breed_no_color_train$AKC.Class)
AKC_factor2 <- AKC_factor2[,-1]
#View(AKC_factor2)

intake_factor2 <- dummy.code(breed_no_color_train$Intake.Type)
#View(intake_factor2)

DOW_factor2 <- dummy.code(breed_no_color_train$DOW)
#View(DOW_factor2)

YEAR_factor2 <- dummy.code(breed_no_color_train$YEAR)
#View(YEAR_factor)


breed_no_color_train$OutCatg <- as.numeric(unclass(factor(breed_no_color_train$OutCatg))-1)

breed_no_color_train_final <- data.frame(sex_dummy2,shelter_dummy2,
                                         micro_factor2, license_factor2, AKC_factor2,
                                         intake_factor2, DOW_factor2, YEAR_factor2,
                                         breed_no_color_train$Age,breed_no_color_train$LOS,
                                         breed_no_color_train$Month,breed_no_color_train$Population,
                                         breed_no_color_train$OutCatg)
#View(breed_no_color_train_final)

bstDense2 <- xgboost(data = as.matrix(breed_no_color_train_final[,-51]), label = breed_no_color_train_final[,51], 
                    missing=NaN, max.depth = 6, eta = 0.01, nround = 3500, num_class=3,
                    objective = "multi:softprob")

#xgb.plot.importance(xgb.importance(colnames(breed_no_color_train_final[,-51]), model = bstDense2))


#____________________


breed_no_color_test <- read.csv("breed_no_color_testing_rdat.csv", header = TRUE)

breed_no_color_test_copy <- read.csv("breed_no_color_testing_rdat.csv", header = TRUE)

#View(breed_no_color_test)
#str(breed_no_color_test)
indicator_vec_test2 <- as.logical(breed_no_color_test$Indicator)

breed_no_color_test <- breed_no_color_test[indicator_vec_test2,]

breed_no_color_test_copy <- breed_no_color_test_copy[indicator_vec_test2,]

sex_dummy_test2 <- dummy.code(breed_no_color_test$Sex)
#View(sex_dummy_test2)

shelter_dummy_test2 <- dummy.code(breed_no_color_test$Shelter)
#View(shelter_dummy_test2)

#color_dummy_test2 <- dummy.code(breed_no_color_test$Primary.Color)
#color_dummy_test2 <- color_dummy_test2[,-c(4,9)]
#View(color_dummy_test2)

micro_factor_test2 <- dummy.code(breed_no_color_test$Micro.Date..Factor.)
#View(micro_factor_test2)

license_factor_test2 <- dummy.code(breed_no_color_test$License.Date..Factor.)
#View(license_factor_test2)

AKC_factor_test2 <- dummy.code(breed_no_color_test$AKC.Class)
AKC_factor_test2 <- AKC_factor_test2[,-1]
#View(AKC_factor_test)

intake_factor_test2 <- dummy.code(breed_no_color_test$Intake.Type)
#View(intake_factor_test2)

DOW_factor_test2 <- dummy.code(breed_no_color_test$DOW)
#View(DOW_factor2)

YEAR_factor_test2 <- dummy.code(breed_no_color_test$YEAR)
#View(YEAR_factor)
breed_no_color_test_final <- data.frame(sex_dummy_test2,shelter_dummy_test2,
                                        micro_factor_test2, license_factor_test2, 
                                        AKC_factor_test2, intake_factor_test2,
                                        DOW_factor_test2, YEAR_factor_test2,
                                        breed_no_color_test$Age,breed_no_color_test$LOS,
                                        breed_no_color_test$Month,breed_no_color_test$Population)
#View(breed_no_color_test_final)

pred2 <- predict(bstDense2, as.matrix(breed_no_color_test_final), missing=NaN)
mypred2 <- data.frame(breed_no_color_test_copy$ARN,matrix(pred2, ncol=3, byrow=TRUE))
names(mypred2) <- c("ARN","ADOPTION","EUTHANASIA","OTHER")
write.csv(mypred2, file="mypred2cp3.csv", row.names=FALSE)
