library(psych)
library(xgboost)

no_breed_no_color_train <- read.csv("no_breed_no_color_training_rdat.csv", header = TRUE)
#View(no_breed_no_color_train)
#str(no_breed_no_color_train)
indicator_vec4 <- as.logical(no_breed_no_color_train$Indicator)
no_breed_no_color_train <- no_breed_no_color_train[indicator_vec4,]

sex_dummy4 <- dummy.code(no_breed_no_color_train$Sex)
#View(sex_dummy4)

shelter_dummy4 <- dummy.code(no_breed_no_color_train$Shelter)
#View(shelter_dummy4)

#color_dummy4 <- dummy.code(no_breed_no_color_train$Primary.Color)
#color_dummy4 <- color_dummy4[,-c(4,9)]
#View(color_dummy4)

micro_factor4 <- dummy.code(no_breed_no_color_train$Micro.Date..Factor.)
#View(micro_factor4)

license_factor4 <- dummy.code(no_breed_no_color_train$License.Date..Factor.)
#View(license_factor4)

#AKC_factor4 <- dummy.code(no_breed_no_color_train$AKC.Class)
#AKC_factor4 <- AKC_factor4[,-1]
#View(AKC_factor4)

intake_factor4 <- dummy.code(no_breed_no_color_train$Intake.Type)
#View(intake_factor4)

DOW_factor4 <- dummy.code(no_breed_no_color_train$DOW)
#View(DOW_factor4)

YEAR_factor4 <- dummy.code(no_breed_no_color_train$YEAR)
#View(YEAR_factor4)


no_breed_no_color_train$OutCatg <- as.numeric(unclass(factor(no_breed_no_color_train$OutCatg))-1)

no_breed_no_color_train_final <- data.frame(sex_dummy4,shelter_dummy4,
                                            micro_factor4, license_factor4, intake_factor4,
                                            DOW_factor4, YEAR_factor4,
                                            no_breed_no_color_train$Age,no_breed_no_color_train$LOS,
                                            no_breed_no_color_train$Month,no_breed_no_color_train$Population,
                                            no_breed_no_color_train$OutCatg)
#View(no_breed_no_color_train_final)

bstDense4 <- xgboost(data = as.matrix(no_breed_no_color_train_final[,-43]), label = no_breed_no_color_train_final[,43], 
                     missing=NaN, max.depth = 9, eta = 0.01, nround = 3000, num_class=3,
                     objective = "multi:softprob")

#xgb.plot.importance(xgb.importance(colnames(no_breed_no_color_train_final[,-43]), model = bstDense4))


#____________________


no_breed_no_color_test <- read.csv("no_breed_no_color_testing_rdat.csv", header = TRUE)

no_breed_no_color_test_copy <- read.csv("no_breed_no_color_testing_rdat.csv", header = TRUE)

#View(no_breed_no_color_test)
#str(no_breed_no_color_test)
indicator_vec_test4 <- as.logical(no_breed_no_color_test$Indicator)

no_breed_no_color_test <- no_breed_no_color_test[indicator_vec_test4,]

no_breed_no_color_test_copy <- no_breed_no_color_test_copy[indicator_vec_test4,]

sex_dummy_test4 <- dummy.code(no_breed_no_color_test$Sex)
#View(sex_dummy_test4)

shelter_dummy_test4 <- dummy.code(no_breed_no_color_test$Shelter)
#View(shelter_dummy_test4)

#color_dummy_test4 <- dummy.code(no_breed_no_color_test$Primary.Color)
#color_dummy_test4 <- color_dummy_test4[,-c(4,9)]
#View(color_dummy_test4)

micro_factor_test4 <- dummy.code(no_breed_no_color_test$Micro.Date..Factor.)
#View(micro_factor_test4)

license_factor_test4 <- dummy.code(no_breed_no_color_test$License.Date..Factor.)
#View(license_factor_test4)

AKC_factor_test4 <- dummy.code(no_breed_no_color_test$AKC.Class)
AKC_factor_test4 <- AKC_factor_test4[,-1]
#View(AKC_factor_test4)

intake_factor_test4 <- dummy.code(no_breed_no_color_test$Intake.Type)
#View(intake_factor_test4)

DOW_factor_test4 <- dummy.code(no_breed_no_color_test$DOW)
#View(DOW_factor4)

YEAR_factor_test4 <- dummy.code(no_breed_no_color_test$YEAR)
#View(YEAR_factor4)

no_breed_no_color_test_final <- data.frame(sex_dummy_test4,shelter_dummy_test4,
                                           micro_factor_test4, license_factor_test4, intake_factor_test4,
                                           DOW_factor_test4, YEAR_factor_test4,
                                           no_breed_no_color_test$Age,no_breed_no_color_test$LOS,
                                           no_breed_no_color_test$Month,no_breed_no_color_test$Population)
#View(no_breed_no_color_test_final)

pred4 <- predict(bstDense4, as.matrix(no_breed_no_color_test_final), missing=NaN)
mypred4 <- data.frame(no_breed_no_color_test_copy$ARN,matrix(pred4, ncol=3, byrow=TRUE))
names(mypred4) <- c("ARN","ADOPTION","EUTHANASIA","OTHER")
write.csv(mypred4, file="mypred4cp4.csv", row.names=FALSE)
