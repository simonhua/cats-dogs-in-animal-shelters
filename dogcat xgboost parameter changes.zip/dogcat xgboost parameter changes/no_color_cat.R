cat_no_color_training <- read.csv("cat_no_color_training_rdat.csv", header = TRUE)
#View(cat_no_color_training)
#str(cat_no_color_training)

cat_no_color_training$Domestic.Indc <- as.factor(cat_no_color_training$Domestic.Indc)

cat_indicator2 <- as.logical(cat_no_color_training$Cat.No.Color)
cat_no_color_training <- cat_no_color_training[cat_indicator2,]

cat_sex2 <- dummy.code(cat_no_color_training$Sex)
#View(cat_sex2)

cat_intake2 <- dummy.code(cat_no_color_training$Intake.Type)
#View(cat_intake)

cat_shelter2 <- dummy.code(cat_no_color_training$Shelter)
#View(cat_shelter)

cat_micro2 <- dummy.code(cat_no_color_training$Micro.Date..Factor.)
#View(cat_micro2)

#cat_no_color <- dummy.code(cat_no_color_training$Primary.Color)
#cat_no_color <- cat_no_color[,-c(7,11)]
#View(cat_no_color)

cat_domestic2 <- dummy.code(cat_no_color_training$Domestic.Indc)
#View(cat_domestic2)

cat_DOW2 <- dummy.code(cat_no_color_training$DOW)
#View(cat_DOW2)

cat_YEAR2 <- dummy.code(cat_no_color_training$YEAR)
#view(cat_YEAR2)


cat_no_color_training$OutCatg.Mod <- as.numeric(unclass(factor(cat_no_color_training$OutCatg.Mod))-1)

cat_no_color_training_final <- data.frame(cat_sex2,cat_intake2,cat_shelter2,cat_micro2,cat_domestic2,
                                          cat_DOW2, cat_YEAR2,
                                          cat_no_color_training$Age,cat_no_color_training$Length.of.Stay,
                                          cat_no_color_training$Month, cat_no_color_training$Population,
                                          cat_no_color_training$OutCatg.Mod)

bstDense6 <- xgboost(data = as.matrix(cat_no_color_training_final[,-41]), label = cat_no_color_training_final[,41], 
                     missing=NaN, max.depth = 9, eta = 0.01, nround = 3000, num_class=3,
                     objective = "multi:softprob")

#xgb.plot.importance(xgb.importance(colnames(cat_no_color_training_final[,-41]), model = bstDense6))


#_________


cat_no_color_test <- read.csv("cat_no_color_test_rdat.csv", header = TRUE)
#View(cat_no_color_test)
#str(cat_no_color_test)

cat_no_color_test_copy <- read.csv("cat_no_color_test_rdat.csv", header = TRUE)

cat_no_color_test$Domestic.Indc <- as.factor(cat_no_color_test$Domestic.Indc)

cat_indicator_test2 <- as.logical(cat_no_color_test$Color.Indc)
cat_no_color_test <- cat_no_color_test[cat_indicator_test2,]

cat_no_color_test_copy <- cat_no_color_test_copy[cat_indicator_test2,]

cat_sex_test2 <- dummy.code(cat_no_color_test$Sex)
#View(cat_sex_test2)

cat_intake_test2 <- dummy.code(cat_no_color_test$Intake.Type)
#View(cat_intake_test)

cat_shelter_test2 <- dummy.code(cat_no_color_test$Shelter)
#View(cat_shelter_test)

cat_micro_test2 <- dummy.code(cat_no_color_test$Micro.Date..Factor.)
#View(cat_micro_test)

cat_prim_color_test2 <- dummy.code(cat_no_color_test$Primary.Color)
cat_prim_color_test2 <- cat_prim_color_test2[,-c(7,11)]
#View(cat_prim_color_test2)

cat_domestic_test2 <- dummy.code(cat_no_color_test$Domestic.Indc)
#View(cat_domestic2)

cat_DOW_test2 <- dummy.code(cat_no_color_test$DOW)
#View(cat_DOW2)

cat_YEAR_test2 <- dummy.code(cat_no_color_test$YEAR)
#view(cat_YEAR2)

cat_no_color_test_final <- data.frame(cat_sex_test2,cat_intake_test2,cat_shelter_test2,cat_micro_test2,
                                      cat_domestic_test2, cat_DOW_test2, cat_YEAR_test2,
                                      cat_no_color_test$Age,
                                      cat_no_color_test$Length.of.Stay,
                                      cat_no_color_test$Month, cat_no_color_test$Population)

pred6 <- predict(bstDense6, as.matrix(cat_no_color_test_final), missing=NaN)
mypred6 <- data.frame(cat_no_color_test_copy$ARN,matrix(pred6, ncol=3, byrow=TRUE))
names(mypred6) <- c("ARN","ADOPTION","EUTHANASIA","OTHER")
write.csv(mypred6, file="mypred6cp4.csv", row.names=FALSE)
