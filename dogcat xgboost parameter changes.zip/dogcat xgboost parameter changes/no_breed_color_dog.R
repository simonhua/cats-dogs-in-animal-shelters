library(psych)
library(xgboost)

no_breed_color_train <- read.csv("no_breed_color_training_rdat.csv", header = TRUE)
#View(no_breed_color_train)
#str(no_breed_color_train)
indicator_vec3 <- as.logical(no_breed_color_train$Indicator)
no_breed_color_train <- no_breed_color_train[indicator_vec3,]

sex_dummy3 <- dummy.code(no_breed_color_train$Sex)
#View(sex_dummy3)

shelter_dummy3 <- dummy.code(no_breed_color_train$Shelter)
#View(shelter_dummy3)

color_dummy3 <- dummy.code(no_breed_color_train$Primary.Color)
color_dummy3 <- color_dummy3[,-c(4,9)]
#View(color_dummy3)

micro_factor3 <- dummy.code(no_breed_color_train$Micro.Date..Factor.)
#View(micro_factor3)

license_factor3 <- dummy.code(no_breed_color_train$License.Date..Factor.)
#View(license_factor3)

#AKC_factor3 <- dummy.code(no_breed_color_train$AKC.Class)
#AKC_factor3 <- AKC_factor3[,-1]
#View(AKC_factor3)

intake_factor3 <- dummy.code(no_breed_color_train$Intake.Type)
#View(intake_factor3)

DOW_factor3 <- dummy.code(no_breed_color_train$DOW)
#View(DOW_factor3)

YEAR_factor3 <- dummy.code(no_breed_color_train$YEAR)
#View(YEAR_factor3)


no_breed_color_train$OutCatg <- as.numeric(unclass(factor(no_breed_color_train$OutCatg))-1)

no_breed_color_train_final <- data.frame(sex_dummy3,shelter_dummy3, color_dummy3,
                                         micro_factor3, license_factor3, intake_factor3,
                                         DOW_factor3, YEAR_factor3,
                                         no_breed_color_train$Age,no_breed_color_train$LOS,
                                         no_breed_color_train$Month,no_breed_color_train$Population,
                                         no_breed_color_train$OutCatg)
#View(no_breed_color_train_final)

bstDense3 <- xgboost(data = as.matrix(no_breed_color_train_final[,-56]), label = no_breed_color_train_final[,56], 
                     missing=NaN, max.depth = 6, eta = 0.01, nround = 3500, num_class=3,
                     objective = "multi:softprob")

#xgb.plot.importance(xgb.importance(colnames(no_breed_color_train_final[,-56]), model = bstDense3))


#____________________


no_breed_color_test <- read.csv("no_breed_color_testing_rdat.csv", header = TRUE)

no_breed_color_test_copy <- read.csv("no_breed_color_testing_rdat.csv", header = TRUE)

#View(no_breed_color_test)
#str(no_breed_color_test)
indicator_vec_test3 <- as.logical(no_breed_color_test$Indicator)

no_breed_color_test <- no_breed_color_test[indicator_vec_test3,]

no_breed_color_test_copy <- no_breed_color_test_copy[indicator_vec_test3,]

sex_dummy_test3 <- dummy.code(no_breed_color_test$Sex)
#View(sex_dummy_test3)

shelter_dummy_test3 <- dummy.code(no_breed_color_test$Shelter)
#View(shelter_dummy_test3)

color_dummy_test3 <- dummy.code(no_breed_color_test$Primary.Color)
color_dummy_test3 <- color_dummy_test3[,-c(4,9)]
#View(color_dummy_test3)

micro_factor_test3 <- dummy.code(no_breed_color_test$Micro.Date..Factor.)
#View(micro_factor_test3)

license_factor_test3 <- dummy.code(no_breed_color_test$License.Date..Factor.)
#View(license_factor_test3)

AKC_factor_test3 <- dummy.code(no_breed_color_test$AKC.Class)
AKC_factor_test3 <- AKC_factor_test3[,-1]
#View(AKC_factor_test3)

intake_factor_test3 <- dummy.code(no_breed_color_test$Intake.Type)
#View(intake_factor_test3)

DOW_factor_test3 <- dummy.code(no_breed_color_test$DOW)
#View(DOW_factor)

YEAR_factor_test3 <- dummy.code(no_breed_color_test$YEAR)
#View(YEAR_factor)


no_breed_color_test_final <- data.frame(sex_dummy_test3,shelter_dummy_test3,
                                        color_dummy_test3, micro_factor_test3, license_factor_test3, 
                                        intake_factor_test3, DOW_factor_test3, YEAR_factor_test3,
                                        no_breed_color_test$Age,no_breed_color_test$LOS,
                                        no_breed_color_test$Month,no_breed_color_test$Population)
#View(no_breed_color_test_final)

pred3 <- predict(bstDense3, as.matrix(no_breed_color_test_final), missing=NaN)
mypred3 <- data.frame(no_breed_color_test_copy$ARN,matrix(pred3, ncol=3, byrow=TRUE))
names(mypred3) <- c("ARN","ADOPTION","EUTHANASIA","OTHER")
write.csv(mypred3, file="mypred3cp3.csv", row.names=FALSE)
